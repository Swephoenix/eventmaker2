<?php

declare(strict_types=1);

namespace OCA\BookedEventsWidget\Service;

use OCA\BookedEventsWidget\AppInfo\Application;

class EventService {
	/**
	 * @return list<array<string, int|string>>
	 */
	public function getEventsWithIds(): array {
		$events = [];

		foreach ($this->readRawEvents() as $index => $event) {
			$events[] = $this->normalizeEvent($event, $index);
		}

		usort($events, static function (array $left, array $right): int {
			$sortComparison = ((int)$left['sort_order']) <=> ((int)$right['sort_order']);
			if ($sortComparison !== 0) {
				return $sortComparison;
			}

			return ((int)$left['id']) <=> ((int)$right['id']);
		});

		return $events;
	}

	/**
	 * @return list<array<string, string>>
	 */
	public function getEvents(): array {
		return array_map(static fn (array $event): array => [
			'title' => (string)$event['title'],
			'date' => (string)$event['date'],
			'location' => (string)$event['location'],
			'description' => (string)$event['description'],
			'link' => (string)$event['link'],
			'isPast' => (bool)$event['is_past'],
		], $this->getEventsWithIds());
	}

	public function hasAnyEvents(): bool {
		return $this->readRawEvents() !== [];
	}

	/**
	 * @param list<array<string, int|string>> $events
	 */
	public function seedEvents(array $events): void {
		$this->writeRawEvents(array_map(function (array $event): array {
			return [
				'title' => (string)$event['title'],
				'date' => (string)$event['date'],
				'location' => (string)$event['location'],
				'description' => (string)($event['description'] ?? ''),
				'link' => (string)($event['link'] ?? ''),
				'sort_order' => (int)($event['sort_order'] ?? 0),
				'source' => (string)($event['source'] ?? $this->detectSource($event)),
				'staff' => $this->normalizeStaff((array)($event['staff'] ?? [])),
				'chat' => $this->normalizeChat((array)($event['chat'] ?? []), (string)($event['title'] ?? '')),
			];
		}, $events));
	}

	public function createEvent(string $title, string $date, string $location, string $description, string $link, int $sortOrder): void {
		$events = $this->readRawEvents();
		$events[] = [
			'title' => trim($title),
			'date' => trim($date),
			'location' => trim($location),
			'description' => trim($description),
			'link' => trim($link),
			'sort_order' => $sortOrder,
			'source' => 'manual',
			'staff' => [],
			'chat' => $this->getDefaultChat(trim($title)),
		];

		$this->writeRawEvents($events);
	}

	public function updateEvent(int $id, string $title, string $date, string $location, string $description, string $link, int $sortOrder): void {
		$events = $this->readRawEvents();

		if (!isset($events[$id])) {
			return;
		}

		$existingEvent = $events[$id];
		$isApiEvent = $this->isApiEvent($existingEvent);

		$existingEvent['title'] = $isApiEvent
			? $this->cleanText((string)($existingEvent['title'] ?? 'Event'))
			: trim($title);
		$existingEvent['date'] = $isApiEvent
			? $this->cleanText((string)($existingEvent['date'] ?? ''))
			: trim($date);
		$existingEvent['location'] = $isApiEvent
			? $this->cleanText((string)($existingEvent['location'] ?? ''))
			: trim($location);
		$existingEvent['description'] = trim($description);
		$existingEvent['link'] = $isApiEvent
			? trim((string)($existingEvent['link'] ?? ''))
			: trim($link);
		$existingEvent['sort_order'] = $sortOrder;
		$existingEvent['source'] = $isApiEvent ? 'api' : 'manual';

		$events[$id] = $existingEvent;

		$this->writeRawEvents($events);
	}

	public function deleteEvent(int $id): void {
		$events = $this->readRawEvents();

		if (!isset($events[$id])) {
			return;
		}

		unset($events[$id]);

		$this->writeRawEvents(array_values($events));
	}

	/**
	 * @param list<array<string, mixed>> $staff
	 */
	public function saveStaff(int $id, array $staff): void {
		$events = $this->readRawEvents();

		if (!isset($events[$id])) {
			return;
		}

		$events[$id]['staff'] = $this->normalizeStaff($staff);
		$this->writeRawEvents($events);
	}

	/**
	 * @param list<array<string, mixed>> $chat
	 */
	public function saveChat(int $id, array $chat): void {
		$events = $this->readRawEvents();

		if (!isset($events[$id])) {
			return;
		}

		$title = $this->cleanText((string)($events[$id]['title'] ?? 'Event'));
		$events[$id]['chat'] = $this->normalizeChat($chat, $title, false);
		$this->writeRawEvents($events);
	}

	/**
	 * @return list<array<string, mixed>>
	 */
	private function readRawEvents(): array {
		$filePath = $this->getEventsFilePath();
		if (!is_file($filePath)) {
			return $this->getDefaultEvents();
		}

		$contents = file_get_contents($filePath);
		if ($contents === false) {
			return $this->getDefaultEvents();
		}

		$events = json_decode($contents, true);
		if (!is_array($events)) {
			return $this->getDefaultEvents();
		}

		$events = array_values(array_filter($events, static fn ($event): bool => is_array($event)));

		return $events !== [] ? $events : $this->getDefaultEvents();
	}

	/**
	 * @param list<array<string, mixed>> $events
	 */
	private function writeRawEvents(array $events): void {
		$filePath = $this->getEventsFilePath();
		$directory = dirname($filePath);

		if (!is_dir($directory)) {
			mkdir($directory, 0775, true);
		}

		file_put_contents(
			$filePath,
			(string)json_encode(array_values($events), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
		);
	}

	/**
	 * @param array<string, mixed> $event
	 * @return array<string, int|string>
	 */
	private function normalizeEvent(array $event, int $index): array {
		$title = $this->cleanText((string)($event['title'] ?? 'Event'));
		$date = $this->cleanText((string)($event['date'] ?? ''));
		$month = $this->cleanText((string)($event['month'] ?? ''));
		$day = $this->cleanText((string)($event['day'] ?? ''));
		$time = $this->cleanText((string)($event['time'] ?? ''));
		$place = $this->cleanText((string)($event['place'] ?? ''));
		$location = $this->cleanText((string)($event['location'] ?? ''));
		$description = $this->cleanText((string)($event['description'] ?? ''));
		$link = trim((string)($event['link'] ?? ''));

		if ($date === '') {
			$date = trim($month . ' ' . $day);
		}
		if ($date === '') {
			$date = 'Datum meddelas';
		}

		if ($location === '') {
			$location = $place;
		}
		if ($location !== '' && $time !== '') {
			$location .= ' • ' . $time;
		} elseif ($location === '' && $time !== '') {
			$location = $time;
		}
		if ($location === '') {
			$location = 'Plats meddelas';
		}

		if ($description === '') {
			$description = sprintf(
				'%s planeras till %s. %s',
				$title,
				mb_strtolower($date),
				$link !== '' ? 'Öppna länken för mer information.' : 'Mer information kommer senare.',
			);
		}

		return [
			'id' => $index,
			'title' => $title,
			'date' => $date,
			'location' => $location,
			'description' => $description,
			'link' => $link,
			'staff' => $this->normalizeStaff((array)($event['staff'] ?? []), $title, $location),
			'chat' => $this->normalizeChat((array)($event['chat'] ?? []), $title),
			'is_api' => $this->isApiEvent($event),
			'is_past' => $this->isPastEvent($month, $day),
			'sort_order' => (int)($event['sort_order'] ?? (($index + 1) * 10)),
		];
	}

	/**
	 * @param list<array<string, mixed>> $staff
	 * @return list<array{userId: string, firstName: string, lastName: string, email: string, role: string, area: string}>
	 */
	private function normalizeStaff(array $staff, string $title = '', string $location = ''): array {
		$normalized = array_values(array_filter(array_map(function (array $person): array {
			return [
				'userId' => trim((string)($person['userId'] ?? '')),
				'firstName' => $this->cleanText((string)($person['firstName'] ?? '')),
				'lastName' => $this->cleanText((string)($person['lastName'] ?? '')),
				'email' => trim((string)($person['email'] ?? '')),
				'role' => $this->cleanText((string)($person['role'] ?? '')),
				'area' => $this->cleanText((string)($person['area'] ?? '')),
			];
		}, array_filter($staff, static fn ($person): bool => is_array($person))), static function (array $person): bool {
			return $person['userId'] !== ''
				|| $person['firstName'] !== ''
				|| $person['lastName'] !== ''
				|| $person['email'] !== ''
				|| $person['role'] !== ''
				|| $person['area'] !== '';
		}));

		if ($normalized !== []) {
			return $normalized;
		}

		return [
			['userId' => '', 'firstName' => 'Eventansvarig', 'lastName' => '', 'email' => '', 'role' => $title, 'area' => 'Övergripande ansvar och samordning'],
			['userId' => '', 'firstName' => 'Representant', 'lastName' => '', 'email' => '', 'role' => 'På plats', 'area' => $location],
			['userId' => '', 'firstName' => 'Volontär', 'lastName' => '', 'email' => '', 'role' => 'Stöd', 'area' => 'Material, välkomnande och praktiskt stöd'],
		];
	}

	/**
	 * @param list<array<string, mixed>> $chat
	 * @return list<array{type: string, text: string, senderLabel: string, senderUserId: string, createdAt: string}>
	 */
	private function normalizeChat(array $chat, string $title = '', bool $withFallback = true): array {
		$normalized = array_values(array_filter(array_map(function (array $message): array {
			$type = trim((string)($message['type'] ?? 'message'));
			if ($type !== 'system') {
				$type = 'message';
			}

			return [
				'type' => $type,
				'text' => $this->cleanText((string)($message['text'] ?? '')),
				'senderLabel' => $this->cleanText((string)($message['senderLabel'] ?? '')),
				'senderUserId' => trim((string)($message['senderUserId'] ?? '')),
				'createdAt' => trim((string)($message['createdAt'] ?? '')),
			];
		}, array_filter($chat, static fn ($message): bool => is_array($message))), static fn (array $message): bool => $message['text'] !== ''));

		if ($normalized !== [] || !$withFallback) {
			return $normalized;
		}

		return $this->getDefaultChat($title);
	}

	/**
	 * @return list<array{type: string, text: string, senderLabel: string, senderUserId: string, createdAt: string}>
	 */
	private function getDefaultChat(string $title = ''): array {
		$context = $title !== '' ? ' för ' . $title : '';

		return [[
			'type' => 'system',
			'text' => 'Gemensam intern chatt' . $context . '. Här samlar eventplanerare och eventpersonal samma information.',
			'senderLabel' => 'System',
			'senderUserId' => '',
			'createdAt' => '',
		]];
	}

	/**
	 * @param array<string, mixed> $event
	 */
	private function detectSource(array $event): string {
		return $this->isApiEvent($event) ? 'api' : 'manual';
	}

	/**
	 * @param array<string, mixed> $event
	 */
	private function isApiEvent(array $event): bool {
		$source = (string)($event['source'] ?? '');
		if ($source === 'api') {
			return true;
		}
		if ($source === 'manual') {
			return false;
		}

		foreach (['month', 'day', 'time', 'place'] as $key) {
			if ($this->cleanText((string)($event[$key] ?? '')) !== '') {
				return true;
			}
		}

		return false;
	}

	private function isPastEvent(string $month, string $day): bool {
		$monthMap = [
			'januari' => 1,
			'februari' => 2,
			'mars' => 3,
			'april' => 4,
			'maj' => 5,
			'juni' => 6,
			'juli' => 7,
			'augusti' => 8,
			'september' => 9,
			'oktober' => 10,
			'november' => 11,
			'december' => 12,
		];

		$monthNumber = $monthMap[mb_strtolower($month)] ?? null;
		if ($monthNumber === null) {
			return false;
		}

		if (!preg_match('/(\d{1,2})(?:\s*-\s*(\d{1,2}))?/', $day, $matches)) {
			return false;
		}

		$endDay = isset($matches[2]) && $matches[2] !== ''
			? (int)$matches[2]
			: (int)$matches[1];

		try {
			$eventDate = new \DateTimeImmutable(sprintf('%d-%02d-%02d', (int)date('Y'), $monthNumber, $endDay));
			$today = new \DateTimeImmutable('today');
		} catch (\Exception) {
			return false;
		}

		return $eventDate < $today;
	}

	private function cleanText(string $value): string {
		$value = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
		$value = preg_replace('/\s+/u', ' ', $value) ?? $value;

		return trim($value);
	}

	private function getEventsFilePath(): string {
		return \OC::$SERVERROOT . '/custom_apps/' . Application::APP_ID . '/data/events.json';
	}

	/**
	 * @return list<array<string, int|string>>
	 */
	private function getDefaultEvents(): array {
		return [
			[
				'title' => 'Årsstämma',
				'date' => 'Datum meddelas',
				'location' => 'Information via medlemsmejl',
				'description' => 'Information om årsstämman skickas ut via medlemsmejl när program och plats är fastställda.',
				'link' => '',
				'sort_order' => 10,
			],
			[
				'title' => 'Seniorfestival Malmö',
				'date' => 'Kommande datum',
				'location' => 'Malmö',
				'description' => 'Seniorfestivalen samlar aktiviteter, inspiration och utställare för en aktiv och social vardag.',
				'link' => 'https://seniorfestivalen.se/malmo/',
				'sort_order' => 20,
			],
			[
				'title' => 'Afterwork med Ambition Sverige',
				'date' => 'Kommande datum',
				'location' => 'RG21',
				'description' => 'Ett informellt tillfälle att träffas, nätverka och prata vidare om kommande aktiviteter.',
				'link' => 'https://rg21.se/',
				'sort_order' => 30,
			],
			[
				'title' => 'Seniordagen',
				'date' => 'Kommande datum',
				'location' => 'Kungsträdgården',
				'description' => 'En dag fylld av utställare, föreläsningar och aktiviteter som inspirerar till en bättre framtid för seniorer.',
				'link' => 'https://seniordagen.com/seniordagen-i-stockholm/index',
				'sort_order' => 40,
			],
		];
	}
}
